// const { generarProducto }  = require ("../DB/fakerProducts")

// class ContenedorFake{
//   constructor() {

//   }
//   getProd(n) {
//     let fakeProducts = []
//     for (let index = 0; index < n; index++) {
//         const nuevoProd = generarProducto()
//         fakeProducts.push(nuevoProd)
//     }
//     return fakeProducts
//     }
    
// }
// module.exports =  ContenedorFake 

